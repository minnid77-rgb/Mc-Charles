# Mc Charles Global – Deploy-Ready Store

**Head Office:** Opposite Big Tree, Elikpokwodu Rukpokwu, Port Harcourt, Nigeria

Orange · White · Grey theme | Paystack cards (worldwide) | Bank/SWIFT | Gift cards | Full admin

## Quick start
1. Open `index.html` or upload the whole folder to any host.
2. Set Paystack public key in `js/app.js` → `PAYSTACK_PUBLIC_KEY`
3. Set bank details in `js/app.js` → `BANK_DETAILS`
4. Admin: **EMEKACHARLES** / **BIG8TREE**

## Customer features
- Sign up → **compulsory random gift card** (discount % / cash bonus ₦ / product credit)
- Use gift code at checkout
- Exchange **cash bonus** cards for cash on P2P page
- Nigeria delivery ₦107/lb · International $0.92/lb
- Worldwide card payments via Paystack

## Admin features
- Sales & order status (pending → shipped → delivered)
- Edit prices & stock
- **Add new products**
- **Add new categories**
- Shipping policy rates & text
- View all issued gift cards
- Revenue & low-stock stats

## Files
```
index.html
css/styles.css
js/products.js
js/app.js
README.md
```
