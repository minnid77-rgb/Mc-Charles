/* Mc Charles Global – App Logic (Auth + Secure Checkout) */
(function () {
  "use strict";

  // ========== CONFIG ==========
  // Replace with your real Paystack PUBLIC key from https://dashboard.paystack.com
  // Never put the SECRET key in frontend code.
  const PAYSTACK_PUBLIC_KEY = "pk_test_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"; // ← replace this

  // Bank details for transfer payments (update with your real account)
  const BANK_DETAILS = {
    bankName: "First Bank of Nigeria",
    accountName: "Mc Charles Global",
    accountNumber: "1234567890",
    swift: "FBNINGLA",
    bankAddress: "Port Harcourt, Rivers State, Nigeria"
  };

  // Admin credentials (demo only – in production use a real backend + hashed passwords)
  const ADMIN_USER = "EMEKACHARLES";
  const ADMIN_PASS = "BIG8TREE";

  // ========== STATE ==========
  let currentCategory = "all";
  let searchQuery = "";
  let minPrice = 0;
  let maxPrice = Infinity;
  let sortBy = "featured";
  let cart = JSON.parse(localStorage.getItem("mcCart") || "[]");
  let currentUser = JSON.parse(localStorage.getItem("mcUser") || "null");
  let isAdmin = sessionStorage.getItem("mcAdmin") === "1";
  let orders = JSON.parse(localStorage.getItem("mcOrders") || "[]");
  let appliedGift = null; // gift card applied at checkout

  function getAllGifts() {
    return JSON.parse(localStorage.getItem("mcGifts") || "[]");
  }
  function saveAllGifts(gifts) {
    localStorage.setItem("mcGifts", JSON.stringify(gifts));
  }
  function getUserGift(userId) {
    return getAllGifts().find(function (g) { return g.userId === userId; });
  }

  // Apply saved price/stock overrides from admin
  (function applyInventoryOverrides() {
    var overrides = JSON.parse(localStorage.getItem("mcInventory") || "{}");
    PRODUCTS.forEach(function (p) {
      if (overrides[p.id]) {
        if (overrides[p.id].price != null) p.price = overrides[p.id].price;
        if (overrides[p.id].stock != null) p.stock = overrides[p.id].stock;
      }
    });
  })();

  // Unique color palette per product id
  var PROD_COLORS = [
    "#ff6a00", "#e11d48", "#7c3aed", "#2563eb", "#0891b2",
    "#059669", "#ca8a04", "#ea580c", "#db2777", "#4f46e5",
    "#0d9488", "#65a30d", "#dc2626", "#9333ea", "#0284c7"
  ];
  function prodColor(id) {
    return PROD_COLORS[(id - 1) % PROD_COLORS.length];
  }

  // ========== DOM ==========
  const productsGrid = document.getElementById("products-grid");
  const noResults = document.getElementById("no-results");
  const sectionTitle = document.getElementById("section-title");
  const resultsCount = document.getElementById("results-count");
  const searchInput = document.getElementById("search-input");
  const searchCategory = document.getElementById("search-category");
  const searchBtn = document.getElementById("search-btn");
  const cartBtn = document.getElementById("cart-btn");
  const cartCount = document.getElementById("cart-count");
  const cartSidebar = document.getElementById("cart-sidebar");
  const cartOverlay = document.getElementById("cart-overlay");
  const cartItems = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");
  const closeCart = document.getElementById("close-cart");
  const checkoutBtn = document.getElementById("checkout-btn");
  const filterToggle = document.getElementById("filter-toggle");
  const sidebar = document.getElementById("sidebar");
  const modal = document.getElementById("product-modal");
  const modalOverlay = document.getElementById("modal-overlay");
  const modalBody = document.getElementById("modal-body");
  const modalClose = document.getElementById("modal-close");
  const accountBtn = document.getElementById("account-btn");
  const accountLabel = document.getElementById("account-label");

  // ========== HELPERS ==========
  function formatPrice(n) {
    return "₦" + Number(n).toLocaleString("en-NG");
  }

  function generateRef() {
    return "MCG" + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 6).toUpperCase();
  }

  function openModalById(id) {
    document.getElementById(id).classList.add("open");
    modalOverlay.classList.add("open");
  }

  function closeModalById(id) {
    document.getElementById(id).classList.remove("open");
    const anyOpen = document.querySelector(".modal.open");
    if (!anyOpen) modalOverlay.classList.remove("open");
  }

  function closeAllModals() {
    document.querySelectorAll(".modal.open").forEach((m) => m.classList.remove("open"));
    modalOverlay.classList.remove("open");
    cartSidebar.classList.remove("open");
    cartOverlay.classList.remove("open");
  }

  // ========== PRODUCTS ==========
  function getFilteredProducts() {
    let list = PRODUCTS.filter((p) => {
      const matchCat = currentCategory === "all" || p.category === currentCategory;
      const matchSearch =
        !searchQuery ||
        p.name.toLowerCase().includes(searchQuery) ||
        p.desc.toLowerCase().includes(searchQuery) ||
        p.category.toLowerCase().includes(searchQuery);
      const matchPrice = p.price >= minPrice && p.price <= maxPrice;
      return matchCat && matchSearch && matchPrice;
    });
    if (sortBy === "price-low") list.sort((a, b) => a.price - b.price);
    else if (sortBy === "price-high") list.sort((a, b) => b.price - a.price);
    else if (sortBy === "name") list.sort((a, b) => a.name.localeCompare(b.name));
    return list;
  }

  function renderProducts() {
    const list = getFilteredProducts();
    sectionTitle.textContent = CATEGORY_NAMES[currentCategory] || "All Products";
    resultsCount.textContent =
      list.length === 0 ? "No items found" : "Showing " + list.length + " item" + (list.length !== 1 ? "s" : "");

    if (list.length === 0) {
      productsGrid.innerHTML = "";
      noResults.hidden = false;
      return;
    }
    noResults.hidden = true;
    productsGrid.innerHTML = list
      .map(function (p) {
        var color = prodColor(p.id);
        var stockLabel =
          p.stock <= 0
            ? '<span class="product-badge" style="background:#dc2626">Out of stock</span>'
            : p.stock <= 5
            ? '<span class="product-badge" style="background:#f59e0b">Low stock</span>'
            : p.badge
            ? '<span class="product-badge ' +
              (p.category === "p2p" ? "p2p" : "") +
              '">' +
              p.badge +
              "</span>"
            : "";
        return (
          '<article class="product-card" data-id="' +
          p.id +
          '">' +
          '<div class="product-img" style="background:linear-gradient(145deg,' +
          color +
          "cc," +
          color +
          '66)">' +
          '<i class="fas ' +
          p.icon +
          '" style="color:#fff;font-size:2.8rem;text-shadow:0 2px 8px rgba(0,0,0,0.2)"></i>' +
          stockLabel +
          "</div>" +
          '<div class="product-body">' +
          '<div class="product-cat">' +
          (CATEGORY_NAMES[p.category] || p.category) +
          "</div>" +
          '<h3 class="product-title">' +
          p.name +
          "</h3>" +
          '<div class="product-price">' +
          formatPrice(p.price) +
          "</div>" +
          '<div class="product-actions">' +
          '<button class="btn-view" data-action="view" data-id="' +
          p.id +
          '">View</button>' +
          '<button class="btn-add" data-action="add" data-id="' +
          p.id +
          '"' +
          (p.stock <= 0 ? " disabled style=opacity:0.5" : "") +
          ">Add</button>" +
          "</div></div></article>"
        );
      })
      .join("");
  }

  // ========== CART ==========
  function saveCart() {
    localStorage.setItem("mcCart", JSON.stringify(cart));
    updateCartUI();
  }

  function getCartTotal() {
    return cart.reduce((s, i) => {
      const p = PRODUCTS.find((x) => x.id === i.id);
      return s + (p ? p.price * i.qty : 0);
    }, 0);
  }

  function getCartWeight() {
    return cart.reduce((s, i) => {
      const p = PRODUCTS.find((x) => x.id === i.id);
      return s + (p ? (p.weight || 1) * i.qty : 0);
    }, 0);
  }

  function calcShipping(isNigeria) {
    const weight = getCartWeight();
    if (isNigeria) {
      return { amountNgn: Math.ceil(weight * SHIPPING.nigeriaPerLb), amountUsd: 0, weight: weight };
    }
    const usd = weight * SHIPPING.internationalPerLb;
    const ngn = Math.ceil(usd * SHIPPING.usdToNgn);
    return { amountNgn: ngn, amountUsd: Math.round(usd * 100) / 100, weight: weight };
  }

  function getGrandTotal(isNigeria) {
    return getCartTotal() + calcShipping(isNigeria).amountNgn;
  }

  function updateCartUI() {
    const totalQty = cart.reduce((s, i) => s + i.qty, 0);
    cartCount.textContent = totalQty;

    if (cart.length === 0) {
      cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
      cartTotal.textContent = "₦0";
      return;
    }

    cartItems.innerHTML = cart
      .map((item) => {
        const p = PRODUCTS.find((x) => x.id === item.id);
        if (!p) return "";
        return (
          '<div class="cart-item" data-id="' + p.id + '">' +
          '<div class="cart-item-img"><i class="fas ' + p.icon + '"></i></div>' +
          '<div class="cart-item-info"><h4>' + p.name + "</h4>" +
          '<div class="price">' + formatPrice(p.price) + "</div>" +
          '<div class="cart-item-qty">' +
          '<button data-action="dec" data-id="' + p.id + '">−</button>' +
          "<span>" + item.qty + "</span>" +
          '<button data-action="inc" data-id="' + p.id + '">+</button>' +
          "</div></div>" +
          '<button class="cart-item-remove" data-action="remove" data-id="' + p.id + '"><i class="fas fa-trash"></i></button>' +
          "</div>"
        );
      })
      .join("");
    cartTotal.textContent = formatPrice(getCartTotal());
  }

  function addToCart(id) {
    const existing = cart.find((i) => i.id === id);
    if (existing) existing.qty += 1;
    else cart.push({ id: id, qty: 1 });
    saveCart();
  }

  function changeQty(id, delta) {
    const item = cart.find((i) => i.id === id);
    if (!item) return;
    item.qty += delta;
    if (item.qty <= 0) cart = cart.filter((i) => i.id !== id);
    saveCart();
  }

  function removeFromCart(id) {
    cart = cart.filter((i) => i.id !== id);
    saveCart();
  }

  // ========== AUTH ==========
  function updateAccountUI() {
    if (isAdmin) accountLabel.textContent = "Admin";
    else if (currentUser) accountLabel.textContent = currentUser.name.split(" ")[0];
    else accountLabel.textContent = "Account";
  }

  function getUsers() {
    return JSON.parse(localStorage.getItem("mcUsers") || "[]");
  }

  function saveUsers(users) {
    localStorage.setItem("mcUsers", JSON.stringify(users));
  }

  function customerSignup(name, email, phone, password, address) {
    const users = getUsers();
    if (users.find((u) => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, msg: "Email already registered. Please login." };
    }
    const user = {
      id: Date.now(),
      name: name,
      email: email,
      phone: phone,
      password: password,
      address: address,
      createdAt: new Date().toISOString()
    };
    users.push(user);
    saveUsers(users);
    currentUser = { id: user.id, name: name, email: email, phone: phone, address: address };
    localStorage.setItem("mcUser", JSON.stringify(currentUser));

    // Compulsory random store gift card
    var gift = generateGiftCard(user.id);
    var gifts = getAllGifts();
    gifts.push(gift);
    saveAllGifts(gifts);

    updateAccountUI();
    renderGiftDisplay();
    return {
      ok: true,
      msg: "Account created! Gift card: " + gift.code + " (" + gift.label + ")"
    };
  }

  function customerLogin(email, password) {
    const users = getUsers();
    const user = users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (!user) return { ok: false, msg: "Invalid email or password." };
    currentUser = {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      address: user.address
    };
    localStorage.setItem("mcUser", JSON.stringify(currentUser));
    updateAccountUI();
    renderGiftDisplay();
    return { ok: true, msg: "Login successful!" };
  }

  function customerLogout() {
    currentUser = null;
    appliedGift = null;
    localStorage.removeItem("mcUser");
    updateAccountUI();
    renderGiftDisplay();
  }

  function adminLogin(user, pass) {
    if (user === ADMIN_USER && pass === ADMIN_PASS) {
      isAdmin = true;
      sessionStorage.setItem("mcAdmin", "1");
      updateAccountUI();
      return true;
    }
    return false;
  }

  function adminLogout() {
    isAdmin = false;
    sessionStorage.removeItem("mcAdmin");
    updateAccountUI();
  }

  // ========== CHECKOUT & PAYMENTS ==========
  function openCheckout() {
    if (cart.length === 0) return;
    closeAllModals();

    const requireLogin = document.getElementById("checkout-require-login");
    const content = document.getElementById("checkout-content");

    if (!currentUser && !isAdmin) {
      requireLogin.hidden = false;
      content.style.opacity = "0.5";
      content.style.pointerEvents = "none";
    } else {
      requireLogin.hidden = true;
      content.style.opacity = "1";
      content.style.pointerEvents = "auto";
      if (currentUser) {
        document.getElementById("bill-name").value = currentUser.name || "";
        document.getElementById("bill-email").value = currentUser.email || "";
        document.getElementById("bill-phone").value = currentUser.phone || "";
        document.getElementById("bill-address").value = currentUser.address || "";
      }
    }

    updateCheckoutTotals();

    document.getElementById("bank-name").textContent = BANK_DETAILS.bankName;
    document.getElementById("bank-account-name").textContent = BANK_DETAILS.accountName;
    document.getElementById("bank-account-number").textContent = BANK_DETAILS.accountNumber;
    document.getElementById("bank-swift").textContent = BANK_DETAILS.swift;
    document.getElementById("bank-address").textContent = BANK_DETAILS.bankAddress;

    openModalById("checkout-modal");
  }

  function isNigeriaSelected() {
    return document.getElementById("bill-country").value === "NG";
  }

  function updateCheckoutTotals() {
    const summary = document.getElementById("checkout-summary");
    summary.innerHTML = cart
      .map((item) => {
        const p = PRODUCTS.find((x) => x.id === item.id);
        if (!p) return "";
        return (
          '<div class="checkout-summary-item"><span>' +
          p.name +
          " × " +
          item.qty +
          "</span><span>" +
          formatPrice(p.price * item.qty) +
          "</span></div>"
        );
      })
      .join("");

    const ng = isNigeriaSelected();
    const ship = calcShipping(ng);
    const subtotal = getCartTotal();
    const grand = subtotal + ship.amountNgn;

    var giftDisc = calcGiftDiscount(subtotal);
    var grandFinal = Math.max(0, grand - giftDisc);
    document.getElementById("checkout-subtotal").textContent = formatPrice(subtotal);
    document.getElementById("checkout-weight").textContent =
      (Math.round(ship.weight * 100) / 100) + " lb";
    document.getElementById("checkout-shipping").textContent = formatPrice(ship.amountNgn);
    document.getElementById("checkout-total").textContent = formatPrice(grandFinal);
    if (giftDisc > 0) {
      document.getElementById("checkout-total").textContent =
        formatPrice(grandFinal) + " (gift −" + formatPrice(giftDisc) + ")";
    }

    const rateNote = document.getElementById("shipping-rate-note");
    const usdNote = document.getElementById("intl-usd-note");
    const countryGroup = document.getElementById("country-name-group");

    if (ng) {
      rateNote.textContent = "Delivery: ₦107 per lb within Nigeria";
      usdNote.hidden = true;
      countryGroup.hidden = true;
    } else {
      rateNote.textContent = "Delivery: $0.92 per lb outside Nigeria";
      usdNote.hidden = false;
      usdNote.textContent =
        "International delivery ≈ $" +
        ship.amountUsd.toFixed(2) +
        " (charged as " +
        formatPrice(ship.amountNgn) +
        " at ~₦" +
        SHIPPING.usdToNgn +
        "/USD)";
      countryGroup.hidden = false;
    }
  }

  function saveOrder(paymentMethod, paymentRef, status) {
    const ng = isNigeriaSelected();
    const ship = calcShipping(ng);
    const subtotal = getCartTotal();
    const order = {
      ref: paymentRef || generateRef(),
      items: cart.map((i) => {
        const p = PRODUCTS.find((x) => x.id === i.id);
        return {
          id: i.id,
          name: p ? p.name : "Item",
          qty: i.qty,
          price: p ? p.price : 0,
          weight: p ? p.weight : 1
        };
      }),
      subtotal: subtotal,
      weight: ship.weight,
      shipping: ship.amountNgn,
      shippingUsd: ship.amountUsd,
      total: subtotal + ship.amountNgn,
      isNigeria: ng,
      customer: {
        name: document.getElementById("bill-name").value,
        email: document.getElementById("bill-email").value,
        phone: document.getElementById("bill-phone").value,
        address: document.getElementById("bill-address").value,
        country: ng
          ? "Nigeria"
          : document.getElementById("bill-country-name").value || "International"
      },
      paymentMethod: paymentMethod,
      status: status,
      createdAt: new Date().toISOString()
    };
    order.giftCode = appliedGift ? appliedGift.code : null;
    order.giftDiscount = calcGiftDiscount(subtotal);
    order.total = Math.max(0, (subtotal + ship.amountNgn) - (order.giftDiscount || 0));

    if (appliedGift) {
      var gifts = getAllGifts();
      var g = gifts.find(function (x) { return x.code === appliedGift.code; });
      if (g) { g.used = true; }
      saveAllGifts(gifts);
      appliedGift = null;
    }

    // Deduct inventory
    (order.items || []).forEach(function (item) {
      var p = PRODUCTS.find(function (x) {
        return x.id === item.id;
      });
      if (p && p.stock != null) {
        p.stock = Math.max(0, p.stock - item.qty);
      }
    });
    saveInventoryOverrides();

    orders.unshift(order);
    localStorage.setItem("mcOrders", JSON.stringify(orders));
    cart = [];
    saveCart();
    renderProducts();
    return order;
  }

  function showSuccess(order) {
    closeAllModals();
    document.getElementById("success-message").textContent =
      order.paymentMethod === "paystack"
        ? "Payment received. We will process and deliver your order soon."
        : "We have recorded your bank transfer request. We will confirm payment and process your order.";
    document.getElementById("order-ref").textContent = order.ref;
    openModalById("success-modal");
  }

  function payWithPaystack() {
    const name = document.getElementById("bill-name").value.trim();
    const email = document.getElementById("bill-email").value.trim();
    const phone = document.getElementById("bill-phone").value.trim();
    const address = document.getElementById("bill-address").value.trim();

    if (!name || !email || !phone || !address) {
      alert("Please fill in all billing details.");
      return;
    }
    if (!isNigeriaSelected()) {
      var cname = document.getElementById("bill-country-name").value.trim();
      if (!cname) {
        alert("Please enter your country name for international delivery.");
        return;
      }
    }
    if (!currentUser && !isAdmin) {
      alert("Please login or create an account first.");
      return;
    }

    var sub = getCartTotal();
    var shipAmt = calcShipping(isNigeriaSelected()).amountNgn;
    var giftDisc = calcGiftDiscount(sub);
    const grand = Math.max(0, sub + shipAmt - giftDisc);
    const amountKobo = grand * 100;
    if (amountKobo < 100) {
      alert("Cart total is too low.");
      return;
    }

    if (PAYSTACK_PUBLIC_KEY.indexOf("xxxxxxxx") !== -1) {
      alert(
        "Paystack is not configured yet.\n\n" +
          "1. Create a free account at https://dashboard.paystack.com\n" +
          "2. Copy your PUBLIC key (pk_test_... or pk_live_...)\n" +
          "3. Paste it into js/app.js as PAYSTACK_PUBLIC_KEY\n\n" +
          "For now you can use Bank Transfer to complete the order."
      );
      return;
    }

    if (typeof PaystackPop === "undefined") {
      alert("Paystack script failed to load. Check your internet connection.");
      return;
    }

    const handler = PaystackPop.setup({
      key: PAYSTACK_PUBLIC_KEY,
      email: email,
      amount: amountKobo,
      currency: "NGN",
      ref: generateRef(),
      metadata: {
        custom_fields: [
          { display_name: "Customer Name", variable_name: "customer_name", value: name },
          { display_name: "Phone", variable_name: "phone", value: phone },
          { display_name: "Address", variable_name: "address", value: address }
        ]
      },
      callback: function (response) {
        // In production: verify response.reference on your backend with the SECRET key
        const order = saveOrder("paystack", response.reference, "paid");
        showSuccess(order);
      },
      onClose: function () {}
    });
    handler.openIframe();
  }

  function payWithBank() {
    const name = document.getElementById("bill-name").value.trim();
    const email = document.getElementById("bill-email").value.trim();
    const phone = document.getElementById("bill-phone").value.trim();
    const address = document.getElementById("bill-address").value.trim();

    if (!name || !email || !phone || !address) {
      alert("Please fill in all billing details.");
      return;
    }
    if (!isNigeriaSelected()) {
      var cname = document.getElementById("bill-country-name").value.trim();
      if (!cname) {
        alert("Please enter your country name for international delivery.");
        return;
      }
    }
    if (!currentUser && !isAdmin) {
      alert("Please login or create an account first.");
      return;
    }

    const order = saveOrder("bank_transfer", generateRef(), "pending_confirmation");
    showSuccess(order);
  }

  // ========== ADMIN PANEL ==========
  function saveInventoryOverrides() {
    var overrides = {};
    PRODUCTS.forEach(function (p) {
      overrides[p.id] = { price: p.price, stock: p.stock };
    });
    localStorage.setItem("mcInventory", JSON.stringify(overrides));
  }

  function getShippingPolicy() {
    return JSON.parse(
      localStorage.getItem("mcShippingPolicy") ||
        JSON.stringify({
          nigeriaPerLb: SHIPPING.nigeriaPerLb,
          internationalPerLb: SHIPPING.internationalPerLb,
          usdToNgn: SHIPPING.usdToNgn,
          text:
            "Delivery within Nigeria: ₦107 per lb.\nInternational: $0.92 per lb.\nOrders are processed within 1–2 business days. Tracking shared after dispatch."
        })
    );
  }

  function applyShippingPolicy(policy) {
    SHIPPING.nigeriaPerLb = Number(policy.nigeriaPerLb) || 107;
    SHIPPING.internationalPerLb = Number(policy.internationalPerLb) || 0.92;
    SHIPPING.usdToNgn = Number(policy.usdToNgn) || 1600;
    localStorage.setItem("mcShippingPolicy", JSON.stringify(policy));
  }

  // Load policy on start
  applyShippingPolicy(getShippingPolicy());

  function renderGiftDisplay() {
    var box = document.getElementById("gift-card-display");
    if (!box) return;
    if (!currentUser) {
      box.innerHTML = '<p class="gift-locked"><i class="fas fa-lock"></i> Sign up or log in to reveal your gift card</p>';
      return;
    }
    var gift = getUserGift(currentUser.id);
    if (!gift) {
      // Issue gift for existing users who signed up before this feature
      gift = generateGiftCard(currentUser.id);
      var gifts = getAllGifts();
      gifts.push(gift);
      saveAllGifts(gifts);
    }
    var valueText =
      gift.type === "discount"
        ? gift.value + "% OFF"
        : gift.type === "cash"
        ? "₦" + gift.value.toLocaleString()
        : "1 Free Product Credit";
    box.innerHTML =
      '<div class="gift-card-inner">' +
      "<h3>Mc Charles Store Gift Card</h3>" +
      '<div class="gift-value">' + valueText + "</div>" +
      "<p>" + gift.label + (gift.used ? " — USED" : " — Active") + "</p>" +
      '<div class="gift-code">' + gift.code + "</div>" +
      '<p class="gift-status">' +
      (gift.used
        ? "Already redeemed"
        : gift.type === "cash"
        ? "Use at checkout or exchange for cash on P2P page"
        : "Apply this code at checkout") +
      "</p></div>";
  }

  function calcGiftDiscount(subtotal) {
    if (!appliedGift || appliedGift.used) return 0;
    if (appliedGift.type === "discount") {
      return Math.floor(subtotal * (appliedGift.value / 100));
    }
    if (appliedGift.type === "cash") {
      return Math.min(appliedGift.value, subtotal);
    }
    // product bonus: free up to cheapest item value capped
    return 0;
  }



  function openAdminPanel() {
    document.getElementById("admin-name-display").textContent = ADMIN_USER;
    refreshAdminStats();
    renderAdminOrders("all");
    renderAdminInventory("");
    loadPolicyForm();
    fillAdminCategorySelect();
    renderAdminCategories();
    renderAdminGifts();
    openModalById("admin-panel-modal");
  }

  function fillAdminCategorySelect() {
    var sel = document.getElementById("ap-category");
    if (!sel) return;
    sel.innerHTML = CATEGORIES.map(function (c) {
      return '<option value="' + c.id + '">' + c.name + "</option>";
    }).join("");
  }

  function renderAdminCategories() {
    var list = document.getElementById("admin-cat-list");
    if (!list) return;
    list.innerHTML = CATEGORIES.map(function (c) {
      return '<span class="cat-chip">' + c.name + " (" + c.id + ")</span>";
    }).join("");
  }

  function renderAdminGifts() {
    var list = document.getElementById("admin-gifts-list");
    if (!list) return;
    var gifts = getAllGifts();
    if (!gifts.length) {
      list.innerHTML = '<p style="color:#777">No gift cards issued yet.</p>';
      return;
    }
    list.innerHTML = gifts
      .slice()
      .reverse()
      .map(function (g) {
        return (
          '<div class="admin-order-card"><strong>' +
          g.code +
          "</strong> — " +
          g.label +
          " (" +
          (g.type === "discount" ? g.value + "%" : g.type === "cash" ? "₦" + g.value : "product") +
          ") " +
          (g.used ? '<span class="status-badge status-cancelled">used</span>' : '<span class="status-badge status-paid">active</span>') +
          "<br><small>User #" +
          g.userId +
          " · " +
          new Date(g.createdAt).toLocaleString() +
          "</small></div>"
        );
      })
      .join("");
  }

  function refreshCategoryUI() {
    CATEGORY_NAMES = getCategoryNames();
    // Rebuild category nav
    var nav = document.getElementById("category-list");
    if (nav) {
      var html = '<li><a href="#" data-category="all" class="' + (currentCategory === "all" ? "active" : "") + '">All</a></li>';
      CATEGORIES.forEach(function (c) {
        html +=
          '<li><a href="#" data-category="' +
          c.id +
          '" class="' +
          (currentCategory === c.id ? "active" : "") +
          '">' +
          c.name.split(" ")[0] +
          "</a></li>";
      });
      nav.innerHTML = html;
      nav.querySelectorAll("[data-category]").forEach(function (el) {
        el.addEventListener("click", function (e) {
          e.preventDefault();
          searchQuery = "";
          searchInput.value = "";
          setCategory(el.dataset.category);
        });
      });
    }
    // Search select + sidebar
    var searchCat = document.getElementById("search-category");
    var filterList = document.getElementById("filter-categories");
    if (searchCat) {
      searchCat.innerHTML =
        '<option value="all">All Categories</option>' +
        CATEGORIES.map(function (c) {
          return '<option value="' + c.id + '">' + c.name + "</option>";
        }).join("");
    }
    if (filterList) {
      filterList.innerHTML =
        '<li><label><input type="radio" name="cat" value="all"' +
        (currentCategory === "all" ? " checked" : "") +
        '> All Items</label></li>' +
        CATEGORIES.map(function (c) {
          return (
            '<li><label><input type="radio" name="cat" value="' +
            c.id +
            '"' +
            (currentCategory === c.id ? " checked" : "") +
            "> " +
            c.name +
            "</label></li>"
          );
        }).join("");
      filterList.querySelectorAll('input[name="cat"]').forEach(function (radio) {
        radio.addEventListener("change", function () {
          setCategory(radio.value);
        });
      });
    }
    fillAdminCategorySelect();
    renderAdminCategories();
  }

  function refreshAdminStats() {
    document.getElementById("admin-orders-count").textContent = orders.length;
    document.getElementById("admin-customers-count").textContent = getUsers().length;
    var revenue = orders
      .filter(function (o) {
        return o.status === "paid" || o.status === "processing" || o.status === "shipped" || o.status === "delivered";
      })
      .reduce(function (s, o) {
        return s + (o.total || 0);
      }, 0);
    document.getElementById("admin-revenue").textContent = formatPrice(revenue);
    var low = PRODUCTS.filter(function (p) {
      return p.stock <= 5;
    }).length;
    document.getElementById("admin-low-stock").textContent = low;
  }

  function renderAdminOrders(filter) {
    var list = document.getElementById("admin-orders-list");
    var filtered =
      filter === "all"
        ? orders
        : orders.filter(function (o) {
            return o.status === filter;
          });
    if (filtered.length === 0) {
      list.innerHTML = '<p style="color:#6b7280">No orders found.</p>';
      return;
    }
    list.innerHTML = filtered
      .map(function (o) {
        var itemsStr = (o.items || [])
          .map(function (i) {
            return i.name + " ×" + i.qty;
          })
          .join(", ");
        return (
          '<div class="admin-order-card" data-ref="' +
          o.ref +
          '">' +
          "<strong>" +
          o.ref +
          '</strong> — ' +
          formatPrice(o.total || 0) +
          ' <span class="status-badge status-' +
          o.status +
          '">' +
          o.status.replace(/_/g, " ") +
          "</span>" +
          "<br><small>" +
          (o.customer ? o.customer.name : "") +
          " · " +
          (o.customer ? o.customer.country || "" : "") +
          " · " +
          o.paymentMethod +
          "</small>" +
          "<br><small>" +
          itemsStr +
          "</small>" +
          "<br><small>" +
          new Date(o.createdAt).toLocaleString() +
          (o.weight ? " · " + o.weight.toFixed(1) + " lb · ship " + formatPrice(o.shipping || 0) : "") +
          "</small>" +
          '<select class="order-status-select" data-ref="' +
          o.ref +
          '">' +
          ["pending_confirmation", "paid", "processing", "shipped", "delivered", "cancelled"]
            .map(function (s) {
              return (
                '<option value="' +
                s +
                '"' +
                (o.status === s ? " selected" : "") +
                ">" +
                s.replace(/_/g, " ") +
                "</option>"
              );
            })
            .join("") +
          "</select></div>"
        );
      })
      .join("");
  }

  function renderAdminInventory(search) {
    var list = document.getElementById("admin-inventory-list");
    var q = (search || "").toLowerCase();
    var items = PRODUCTS.filter(function (p) {
      return !q || p.name.toLowerCase().indexOf(q) !== -1 || p.category.indexOf(q) !== -1;
    });
    list.innerHTML = items
      .map(function (p) {
        var color = prodColor(p.id);
        return (
          '<div class="inv-row' +
          (p.stock <= 5 ? " low-stock" : "") +
          '" data-id="' +
          p.id +
          '">' +
          '<div class="inv-thumb" style="background:' +
          color +
          '"><i class="fas ' +
          p.icon +
          '"></i></div>' +
          '<div class="inv-name">' +
          p.name +
          "<small>" +
          (CATEGORY_NAMES[p.category] || p.category) +
          " · " +
          (p.weight || 1) +
          " lb</small></div>" +
          '<input type="number" class="inv-price" value="' +
          p.price +
          '" min="0" step="100" title="Price (₦)">' +
          '<input type="number" class="inv-stock" value="' +
          p.stock +
          '" min="0" step="1" title="Stock">' +
          '<button class="btn-save-row" data-id="' +
          p.id +
          '">Save</button></div>'
        );
      })
      .join("");
  }

  function loadPolicyForm() {
    var policy = getShippingPolicy();
    document.getElementById("policy-ng-rate").value = policy.nigeriaPerLb;
    document.getElementById("policy-intl-rate").value = policy.internationalPerLb;
    document.getElementById("policy-usd-ngn").value = policy.usdToNgn;
    document.getElementById("policy-text").value = policy.text || "";
  }

  // ========== PRODUCT MODAL ==========
  function openProductModal(id) {
    const p = PRODUCTS.find((x) => x.id === id);
    if (!p) return;
    var color = prodColor(p.id);
    modalBody.innerHTML =
      '<div class="modal-img" style="background:linear-gradient(145deg,' +
      color +
      "," +
      color +
      '99)"><i class="fas ' +
      p.icon +
      '" style="color:#fff"></i></div>' +
      '<div class="modal-cat">' +
      CATEGORY_NAMES[p.category] +
      "</div>" +
      '<h2 class="modal-title">' +
      p.name +
      "</h2>" +
      '<div class="modal-price">' +
      formatPrice(p.price) +
      "</div>" +
      '<p class="modal-desc">' +
      p.desc +
      "</p>" +
      '<button class="btn btn-primary btn-block" data-action="add-modal" data-id="' +
      p.id +
      '"><i class="fas fa-cart-plus"></i> Add to Cart</button>';
    modal.classList.add("open");
    modalOverlay.classList.add("open");
  }

  // ========== CATEGORY ==========
  function setCategory(cat) {
    currentCategory = cat;
    document.querySelectorAll(".category-list a").forEach((a) => {
      a.classList.toggle("active", a.dataset.category === cat);
    });
    const radio = document.querySelector('input[name="cat"][value="' + cat + '"]');
    if (radio) radio.checked = true;
    if (searchCategory) searchCategory.value = cat === "all" ? "all" : cat;
    renderProducts();
  }

  // ========== EVENTS ==========
  function doSearch() {
    searchQuery = searchInput.value.trim().toLowerCase();
    const cat = searchCategory.value;
    if (cat !== "all") currentCategory = cat;
    else if (!searchQuery) currentCategory = "all";
    setCategory(currentCategory);
  }
  searchBtn.addEventListener("click", doSearch);
  searchInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") doSearch();
  });

  document.querySelectorAll("[data-category]").forEach(function (el) {
    el.addEventListener("click", function (e) {
      e.preventDefault();
      var cat = el.dataset.category;
      if (cat) {
        searchQuery = "";
        searchInput.value = "";
        minPrice = 0;
        maxPrice = Infinity;
        document.getElementById("min-price").value = "";
        document.getElementById("max-price").value = "";
        setCategory(cat);
      }
    });
  });

  document.querySelectorAll('input[name="cat"]').forEach(function (radio) {
    radio.addEventListener("change", function () {
      searchQuery = "";
      searchInput.value = "";
      setCategory(radio.value);
      if (window.innerWidth <= 960) sidebar.classList.remove("open");
    });
  });

  document.getElementById("apply-price").addEventListener("click", function () {
    var min = parseInt(document.getElementById("min-price").value, 10);
    var max = parseInt(document.getElementById("max-price").value, 10);
    minPrice = isNaN(min) ? 0 : min;
    maxPrice = isNaN(max) ? Infinity : max;
    renderProducts();
  });

  document.getElementById("sort-select").addEventListener("change", function (e) {
    sortBy = e.target.value;
    renderProducts();
  });

  document.getElementById("clear-filters").addEventListener("click", function () {
    searchQuery = "";
    searchInput.value = "";
    minPrice = 0;
    maxPrice = Infinity;
    document.getElementById("min-price").value = "";
    document.getElementById("max-price").value = "";
    sortBy = "featured";
    document.getElementById("sort-select").value = "featured";
    setCategory("all");
  });

  productsGrid.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-action]");
    if (!btn) {
      var card = e.target.closest(".product-card");
      if (card) openProductModal(parseInt(card.dataset.id, 10));
      return;
    }
    var id = parseInt(btn.dataset.id, 10);
    if (btn.dataset.action === "add") {
      addToCart(id);
      btn.textContent = "Added!";
      setTimeout(function () {
        btn.textContent = "Add";
      }, 800);
    } else if (btn.dataset.action === "view") {
      openProductModal(id);
    }
  });

  modalBody.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-action='add-modal']");
    if (btn) {
      addToCart(parseInt(btn.dataset.id, 10));
      btn.innerHTML = '<i class="fas fa-check"></i> Added to Cart';
      setTimeout(function () {
        modal.classList.remove("open");
        if (!document.querySelector(".modal.open")) modalOverlay.classList.remove("open");
      }, 500);
    }
  });

  cartBtn.addEventListener("click", function () {
    cartSidebar.classList.add("open");
    cartOverlay.classList.add("open");
  });
  closeCart.addEventListener("click", function () {
    cartSidebar.classList.remove("open");
    cartOverlay.classList.remove("open");
  });
  cartOverlay.addEventListener("click", function () {
    cartSidebar.classList.remove("open");
    cartOverlay.classList.remove("open");
  });
  cartItems.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-action]");
    if (!btn) return;
    var id = parseInt(btn.dataset.id, 10);
    if (btn.dataset.action === "inc") changeQty(id, 1);
    else if (btn.dataset.action === "dec") changeQty(id, -1);
    else if (btn.dataset.action === "remove") removeFromCart(id);
  });
  checkoutBtn.addEventListener("click", function () {
    cartSidebar.classList.remove("open");
    cartOverlay.classList.remove("open");
    openCheckout();
  });

  document.querySelectorAll("[data-close]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      closeModalById(btn.dataset.close);
    });
  });
  modalClose.addEventListener("click", function () {
    modal.classList.remove("open");
    if (!document.querySelector(".modal.open")) modalOverlay.classList.remove("open");
  });
  modalOverlay.addEventListener("click", closeAllModals);

  accountBtn.addEventListener("click", function () {
    if (isAdmin) {
      openAdminPanel();
    } else if (currentUser) {
      if (confirm("Logged in as " + currentUser.name + ".\n\nClick OK to logout.")) {
        customerLogout();
      }
    } else {
      openModalById("account-choice-modal");
    }
  });

  document.getElementById("open-customer-auth").addEventListener("click", function () {
    closeModalById("account-choice-modal");
    openModalById("customer-auth-modal");
  });
  document.getElementById("open-admin-auth").addEventListener("click", function () {
    closeModalById("account-choice-modal");
    openModalById("admin-auth-modal");
  });

  document.querySelectorAll(".auth-tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      document.querySelectorAll(".auth-tab").forEach(function (t) {
        t.classList.remove("active");
      });
      tab.classList.add("active");
      var isLogin = tab.dataset.tab === "login";
      document.getElementById("customer-login-form").hidden = !isLogin;
      document.getElementById("customer-signup-form").hidden = isLogin;
    });
  });

  document.getElementById("customer-login-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var email = document.getElementById("login-email").value.trim();
    var password = document.getElementById("login-password").value;
    var result = customerLogin(email, password);
    var msg = document.getElementById("login-msg");
    msg.textContent = result.msg;
    msg.className = "form-msg " + (result.ok ? "success" : "error");
    if (result.ok) {
      setTimeout(function () {
        closeModalById("customer-auth-modal");
        msg.textContent = "";
      }, 800);
    }
  });

  document.getElementById("customer-signup-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var name = document.getElementById("signup-name").value.trim();
    var email = document.getElementById("signup-email").value.trim();
    var phone = document.getElementById("signup-phone").value.trim();
    var password = document.getElementById("signup-password").value;
    var address = document.getElementById("signup-address").value.trim();
    var result = customerSignup(name, email, phone, password, address);
    var msg = document.getElementById("signup-msg");
    msg.textContent = result.msg;
    msg.className = "form-msg " + (result.ok ? "success" : "error");
    if (result.ok) {
      setTimeout(function () {
        closeModalById("customer-auth-modal");
        msg.textContent = "";
      }, 800);
    }
  });

  document.getElementById("admin-login-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var user = document.getElementById("admin-user").value.trim();
    var pass = document.getElementById("admin-password").value;
    var msg = document.getElementById("admin-msg");
    if (adminLogin(user, pass)) {
      msg.textContent = "Login successful!";
      msg.className = "form-msg success";
      setTimeout(function () {
        closeModalById("admin-auth-modal");
        openAdminPanel();
        msg.textContent = "";
      }, 600);
    } else {
      msg.textContent = "Invalid admin credentials.";
      msg.className = "form-msg error";
    }
  });

  document.getElementById("admin-logout-btn").addEventListener("click", function () {
    adminLogout();
    closeModalById("admin-panel-modal");
  });

  document.getElementById("checkout-login-prompt").addEventListener("click", function () {
    closeModalById("checkout-modal");
    openModalById("account-choice-modal");
  });

  document.querySelectorAll('input[name="pay-method"]').forEach(function (radio) {
    radio.addEventListener("change", function () {
      var isPaystack = radio.value === "paystack";
      document.getElementById("paystack-info").hidden = !isPaystack;
      document.getElementById("bank-info").hidden = isPaystack;
    });
  });

  // Country / shipping update
  var billCountry = document.getElementById("bill-country");
  if (billCountry) {
    billCountry.addEventListener("change", function () {
      updateCheckoutTotals();
    });
  }

  document.getElementById("pay-paystack-btn").addEventListener("click", payWithPaystack);
  document.getElementById("pay-bank-btn").addEventListener("click", payWithBank);

  filterToggle.addEventListener("click", function () {
    sidebar.classList.toggle("open");
  });
  document.addEventListener("click", function (e) {
    if (
      window.innerWidth <= 960 &&
      sidebar.classList.contains("open") &&
      !sidebar.contains(e.target) &&
      !filterToggle.contains(e.target)
    ) {
      sidebar.classList.remove("open");
    }
  });

  // Admin tabs
  document.querySelectorAll(".admin-tab").forEach(function (tab) {
    tab.addEventListener("click", function () {
      document.querySelectorAll(".admin-tab").forEach(function (t) {
        t.classList.remove("active");
      });
      tab.classList.add("active");
      document.querySelectorAll(".admin-tab-panel").forEach(function (p) {
        p.hidden = true;
        p.classList.remove("active");
      });
      var panel = document.getElementById("atab-" + tab.dataset.atab);
      if (panel) {
        panel.hidden = false;
        panel.classList.add("active");
      }
    });
  });

  // Order status filter
  var orderFilter = document.getElementById("order-status-filter");
  if (orderFilter) {
    orderFilter.addEventListener("change", function () {
      renderAdminOrders(orderFilter.value);
    });
  }

  // Order status change
  document.getElementById("admin-orders-list").addEventListener("change", function (e) {
    var sel = e.target.closest(".order-status-select");
    if (!sel) return;
    var ref = sel.dataset.ref;
    var order = orders.find(function (o) {
      return o.ref === ref;
    });
    if (order) {
      order.status = sel.value;
      localStorage.setItem("mcOrders", JSON.stringify(orders));
      refreshAdminStats();
      renderAdminOrders(document.getElementById("order-status-filter").value);
    }
  });

  // Inventory search
  var invSearch = document.getElementById("inv-search");
  if (invSearch) {
    invSearch.addEventListener("input", function () {
      renderAdminInventory(invSearch.value);
    });
  }

  // Inventory save row
  document.getElementById("admin-inventory-list").addEventListener("click", function (e) {
    var btn = e.target.closest(".btn-save-row");
    if (!btn) return;
    var id = parseInt(btn.dataset.id, 10);
    var row = btn.closest(".inv-row");
    var price = parseInt(row.querySelector(".inv-price").value, 10);
    var stock = parseInt(row.querySelector(".inv-stock").value, 10);
    var p = PRODUCTS.find(function (x) {
      return x.id === id;
    });
    if (!p) return;
    if (!isNaN(price) && price >= 0) p.price = price;
    if (!isNaN(stock) && stock >= 0) p.stock = stock;
    saveInventoryOverrides();
    btn.textContent = "Saved";
    setTimeout(function () {
      btn.textContent = "Save";
    }, 1000);
    renderProducts();
    refreshAdminStats();
    renderAdminInventory(document.getElementById("inv-search").value);
  });

  // Shipping policy save
  document.getElementById("save-shipping-policy").addEventListener("click", function () {
    var policy = {
      nigeriaPerLb: parseFloat(document.getElementById("policy-ng-rate").value) || 107,
      internationalPerLb: parseFloat(document.getElementById("policy-intl-rate").value) || 0.92,
      usdToNgn: parseFloat(document.getElementById("policy-usd-ngn").value) || 1600,
      text: document.getElementById("policy-text").value
    };
    applyShippingPolicy(policy);
    var msg = document.getElementById("policy-msg");
    msg.textContent = "Shipping policy saved.";
    msg.className = "form-msg success";
    setTimeout(function () {
      msg.textContent = "";
    }, 2000);
  });

  // Apply gift code at checkout
  var applyGiftBtn = document.getElementById("apply-gift-btn");
  if (applyGiftBtn) {
    applyGiftBtn.addEventListener("click", function () {
      var code = document.getElementById("gift-code-input").value.trim().toUpperCase();
      var msg = document.getElementById("gift-apply-msg");
      var gifts = getAllGifts();
      var g = gifts.find(function (x) { return x.code === code; });
      if (!g) {
        msg.textContent = "Invalid gift code.";
        msg.className = "form-msg error";
        return;
      }
      if (g.used) {
        msg.textContent = "This gift card was already used.";
        msg.className = "form-msg error";
        return;
      }
      if (currentUser && g.userId !== currentUser.id) {
        msg.textContent = "This gift card belongs to another account.";
        msg.className = "form-msg error";
        return;
      }
      appliedGift = g;
      msg.textContent = "Gift applied: " + g.label + "!";
      msg.className = "form-msg success";
      updateCheckoutTotals();
    });
  }

  // Gift redeem for cash on P2P
  var openGiftRedeem = document.getElementById("open-gift-redeem");
  if (openGiftRedeem) {
    openGiftRedeem.addEventListener("click", function () {
      var content = document.getElementById("gift-redeem-content");
      var confirmBtn = document.getElementById("confirm-gift-redeem");
      var msg = document.getElementById("gift-redeem-msg");
      msg.textContent = "";
      if (!currentUser) {
        content.innerHTML = "<p>Please log in first to redeem your gift card.</p>";
        confirmBtn.hidden = true;
        openModalById("gift-redeem-modal");
        return;
      }
      var gift = getUserGift(currentUser.id);
      if (!gift || gift.used) {
        content.innerHTML = "<p>No active gift card found (or already used).</p>";
        confirmBtn.hidden = true;
      } else if (gift.type !== "cash") {
        content.innerHTML =
          "<p>Your gift is a <strong>" +
          gift.label +
          "</strong> (" +
          (gift.type === "discount" ? gift.value + "%" : "product credit") +
          "). Only <strong>cash bonus</strong> cards can be exchanged for cash. Use discount/product cards at checkout.</p>";
        confirmBtn.hidden = true;
      } else {
        content.innerHTML =
          "<p>Cash bonus: <strong>₦" +
          gift.value.toLocaleString() +
          "</strong></p><p>Code: <code>" +
          gift.code +
          "</code></p><p>We will contact you on your registered phone to arrange cash pickup at the head office or transfer.</p>";
        confirmBtn.hidden = false;
      }
      openModalById("gift-redeem-modal");
    });
  }

  var confirmGiftRedeem = document.getElementById("confirm-gift-redeem");
  if (confirmGiftRedeem) {
    confirmGiftRedeem.addEventListener("click", function () {
      if (!currentUser) return;
      var gifts = getAllGifts();
      var g = gifts.find(function (x) { return x.userId === currentUser.id && !x.used && x.type === "cash"; });
      if (!g) return;
      g.used = true;
      g.redeemedForCash = true;
      saveAllGifts(gifts);
      document.getElementById("gift-redeem-msg").textContent =
        "Request submitted. Visit Opposite Big Tree, Elikpokwodu Rukpokwu with your ID to collect cash, or wait for our call.";
      document.getElementById("gift-redeem-msg").className = "form-msg success";
      confirmGiftRedeem.hidden = true;
      renderGiftDisplay();
    });
  }

  // Add product form
  var addProductForm = document.getElementById("add-product-form");
  if (addProductForm) {
    addProductForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var name = document.getElementById("ap-name").value.trim();
      var cat = document.getElementById("ap-category").value;
      var price = parseInt(document.getElementById("ap-price").value, 10);
      var stock = parseInt(document.getElementById("ap-stock").value, 10);
      var weight = parseFloat(document.getElementById("ap-weight").value);
      var desc = document.getElementById("ap-desc").value.trim();
      var icon = document.getElementById("ap-icon").value.trim() || "fa-box";
      if (icon.indexOf("fa-") !== 0) icon = "fa-" + icon;
      var maxId = PRODUCTS.reduce(function (m, p) { return Math.max(m, p.id); }, 0);
      var product = {
        id: maxId + 1,
        name: name,
        category: cat,
        price: price,
        weight: weight,
        stock: stock,
        icon: icon,
        badge: "New",
        desc: desc
      };
      PRODUCTS.push(product);
      saveInventoryOverrides();
      // Persist custom products
      var custom = JSON.parse(localStorage.getItem("mcCustomProducts") || "[]");
      custom.push(product);
      localStorage.setItem("mcCustomProducts", JSON.stringify(custom));
      document.getElementById("ap-msg").textContent = "Product added: " + name;
      document.getElementById("ap-msg").className = "form-msg success";
      addProductForm.reset();
      document.getElementById("ap-stock").value = 20;
      document.getElementById("ap-weight").value = 1;
      document.getElementById("ap-icon").value = "fa-box";
      renderProducts();
      renderAdminInventory("");
      refreshAdminStats();
    });
  }

  // Add category form
  var addCatForm = document.getElementById("add-category-form");
  if (addCatForm) {
    addCatForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var id = document.getElementById("ac-id").value.trim().toLowerCase().replace(/\s+/g, "-");
      var name = document.getElementById("ac-name").value.trim();
      var msg = document.getElementById("ac-msg");
      if (CATEGORIES.find(function (c) { return c.id === id; })) {
        msg.textContent = "Category ID already exists.";
        msg.className = "form-msg error";
        return;
      }
      CATEGORIES.push({ id: id, name: name });
      localStorage.setItem("mcCategories", JSON.stringify(CATEGORIES));
      CATEGORY_NAMES = getCategoryNames();
      refreshCategoryUI();
      msg.textContent = "Category added: " + name;
      msg.className = "form-msg success";
      addCatForm.reset();
    });
  }

  // Load custom products on start
  (function loadCustomProducts() {
    var custom = JSON.parse(localStorage.getItem("mcCustomProducts") || "[]");
    custom.forEach(function (cp) {
      if (!PRODUCTS.find(function (p) { return p.id === cp.id; })) {
        PRODUCTS.push(cp);
      }
    });
  })();

  // ========== INIT ==========
  updateAccountUI();
  updateCartUI();
  renderProducts();
  renderGiftDisplay();
})();
