/* Mc Charles Global – Product Catalog (weight in pounds) */
const PRODUCTS = [
  // Electrical Parts
  { id: 1, name: "Copper Electrical Cable 2.5mm (100m)", category: "electrical", price: 18500, weight: 12.5, stock: 50, icon: "fa-plug", badge: "Popular", desc: "High-quality pure copper cable for house wiring. 2.5mm², 100 metres roll. Durable insulation." },
  { id: 2, name: "Circuit Breaker 32A Single Pole", category: "electrical", price: 3200, weight: 0.4, stock: 30, icon: "fa-bolt", badge: null, desc: "Reliable MCB for overload and short-circuit protection. Compatible with standard distribution boards." },
  { id: 3, name: "Distribution Board 8-Way", category: "electrical", price: 12500, weight: 4.5, stock: 25, icon: "fa-th", badge: null, desc: "Metal enclosure distribution board with 8 ways. Suitable for residential and small commercial use." },
  { id: 4, name: "LED Tube Light 4ft 18W", category: "electrical", price: 2800, weight: 0.6, stock: 100, icon: "fa-lightbulb", badge: "Sale", desc: "Energy-saving LED tube. Bright white light, long lifespan. Direct replacement for fluorescent tubes." },
  { id: 5, name: "Changeover Switch 63A", category: "electrical", price: 9800, weight: 1.8, stock: 40, icon: "fa-toggle-on", badge: null, desc: "Manual changeover switch for generator and mains. Heavy-duty contacts for reliable switching." },

  // Mechanical Parts
  { id: 6, name: "Ball Bearing 6205-2RS", category: "mechanical", price: 1500, weight: 0.3, stock: 80, icon: "fa-cog", badge: null, desc: "Sealed deep groove ball bearing. Common size for motors, pumps and industrial equipment." },
  { id: 7, name: "V-Belt A-Section 50 inches", category: "mechanical", price: 2200, weight: 0.5, stock: 60, icon: "fa-circle-notch", badge: null, desc: "Industrial rubber V-belt. High tensile strength, oil and heat resistant." },
  { id: 8, name: "Shaft Coupling Flexible", category: "mechanical", price: 4500, weight: 1.2, stock: 45, icon: "fa-link", badge: null, desc: "Flexible shaft coupling for connecting motor to pump or gearbox. Absorbs misalignment." },
  { id: 9, name: "Gearbox Oil Seal Kit", category: "mechanical", price: 3800, weight: 0.4, stock: 70, icon: "fa-ring", badge: null, desc: "Complete oil seal set for common industrial gearboxes. Prevents oil leakage." },

  // Car Parts
  { id: 10, name: "Brake Pad Set – Toyota Camry", category: "car", price: 12500, weight: 3.5, stock: 35, icon: "fa-car", badge: "Popular", desc: "Ceramic brake pads for Toyota Camry. Low dust, quiet operation, long lasting." },
  { id: 11, name: "Oil Filter – Universal", category: "car", price: 1800, weight: 0.7, stock: 90, icon: "fa-oil-can", badge: null, desc: "High-quality oil filter suitable for many Japanese and Korean vehicles." },
  { id: 12, name: "Spark Plug Set (4pcs)", category: "car", price: 4500, weight: 0.5, stock: 55, icon: "fa-fire", badge: null, desc: "Iridium spark plugs. Improved ignition, better fuel economy and smoother engine." },
  { id: 13, name: "Car Battery 12V 75Ah", category: "car", price: 42000, weight: 35, stock: 20, icon: "fa-car-battery", badge: null, desc: "Maintenance-free car battery. Strong cranking power. 12 months warranty." },
  { id: 14, name: "Air Filter – Honda Accord", category: "car", price: 3500, weight: 0.8, stock: 65, icon: "fa-wind", badge: null, desc: "OEM-style air filter. Protects engine from dust and improves airflow." },

  // Generator Parts
  { id: 15, name: "Generator AVR 5KVA", category: "generator", price: 18500, weight: 1.5, stock: 40, icon: "fa-server", badge: "Popular", desc: "Automatic Voltage Regulator for 5KVA generators. Stabilises output voltage." },
  { id: 16, name: "Generator Carburetor 3.5–5KVA", category: "generator", price: 9800, weight: 1.0, stock: 30, icon: "fa-gas-pump", badge: null, desc: "Replacement carburettor for petrol generators. Easy install, reliable fuel delivery." },
  { id: 17, name: "Recoil Starter Assembly", category: "generator", price: 6500, weight: 2.2, stock: 25, icon: "fa-sync", badge: null, desc: "Complete recoil starter for portable generators. Heavy-duty rope and spring." },
  { id: 18, name: "Generator Fuel Tank Cap", category: "generator", price: 1200, weight: 0.3, stock: 100, icon: "fa-tint", badge: null, desc: "Lockable fuel tank cap with seal. Fits most 2–7KVA portable generators." },
  { id: 19, name: "Spark Plug for Generator", category: "generator", price: 1500, weight: 0.15, stock: 80, icon: "fa-bolt", badge: null, desc: "Generator-specific spark plug. Ensures easy starting and smooth running." },

  // Tools & Repair
  { id: 20, name: "Mechanic Tool Set 108pcs", category: "tools", price: 28500, weight: 18, stock: 15, icon: "fa-toolbox", badge: "Best Seller", desc: "Complete socket and spanner set in metal case. Chrome vanadium steel." },
  { id: 21, name: "Digital Multimeter", category: "tools", price: 8500, weight: 0.9, stock: 40, icon: "fa-tachometer-alt", badge: null, desc: "Auto-ranging multimeter for voltage, current, resistance and continuity tests." },
  { id: 22, name: "Angle Grinder 850W", category: "tools", price: 19500, weight: 5.5, stock: 20, icon: "fa-cut", badge: null, desc: "Powerful angle grinder for cutting and grinding metal. Includes disc." },
  { id: 23, name: "Pipe Wrench 14 inch", category: "tools", price: 4200, weight: 2.0, stock: 50, icon: "fa-wrench", badge: null, desc: "Heavy-duty pipe wrench. Adjustable jaws, strong grip for plumbing and mechanical work." },
  { id: 24, name: "Soldering Iron Kit 60W", category: "tools", price: 5500, weight: 1.1, stock: 35, icon: "fa-tools", badge: null, desc: "Adjustable temperature soldering iron with stand, solder and tips. Ideal for electronics." },

  // Warehouse Parts
  { id: 25, name: "Heavy Duty Castor Wheel 4\"", category: "warehouse", price: 3200, weight: 1.5, stock: 60, icon: "fa-dharmachakra", badge: null, desc: "Swivel castor with brake. Load capacity 100kg. For trolleys and racks." },
  { id: 26, name: "Pallet Jack Hydraulic 2.5T", category: "warehouse", price: 145000, weight: 145, stock: 8, icon: "fa-dolly", badge: null, desc: "Manual hydraulic pallet truck. 2.5 tonne capacity. Smooth operation." },
  { id: 27, name: "Steel Storage Rack Shelf", category: "warehouse", price: 18500, weight: 28, stock: 12, icon: "fa-warehouse", badge: null, desc: "Adjustable steel shelf unit. Strong and durable for warehouse or workshop storage." },
  { id: 28, name: "Safety Helmet Yellow", category: "warehouse", price: 2800, weight: 0.8, stock: 40, icon: "fa-hard-hat", badge: null, desc: "Industrial safety helmet. Lightweight, adjustable, meets safety standards." },

  // Solar Fans
  { id: 29, name: "Solar Standing Fan 16\" Rechargeable", category: "fans", price: 28500, weight: 9.5, stock: 25, icon: "fa-fan", badge: "Popular", desc: "16-inch solar rechargeable standing fan. Remote control, LED light, long battery life." },
  { id: 30, name: "Solar Ceiling Fan 56\" with Light", category: "fans", price: 42000, weight: 14, stock: 18, icon: "fa-fan", badge: "New", desc: "Solar-powered ceiling fan with LED light. Quiet operation, 3 speeds, remote included." },
  { id: 31, name: "Solar Standing Fan 18\" Heavy Duty", category: "fans", price: 35500, weight: 11, stock: 22, icon: "fa-fan", badge: null, desc: "Large 18-inch solar fan. Powerful airflow, dual battery option, ideal for shops." },
  { id: 32, name: "Solar Desk Fan Portable", category: "fans", price: 12500, weight: 2.5, stock: 30, icon: "fa-fan", badge: null, desc: "Compact solar desk fan. USB charging, foldable, perfect for office or travel." },

  // Lighting / Bulbs
  { id: 33, name: "LED Bulb 12W Pack of 4", category: "lighting", price: 3200, weight: 0.5, stock: 100, icon: "fa-lightbulb", badge: "Sale", desc: "Energy-efficient LED bulbs. Warm white. Equivalent to 75W traditional bulb." },
  { id: 34, name: "LED Flood Light 50W", category: "lighting", price: 8500, weight: 1.8, stock: 45, icon: "fa-sun", badge: null, desc: "Outdoor LED flood light. Waterproof, bright white light for security or compound." },
  { id: 35, name: "Smart LED Bulb Colour Changing", category: "lighting", price: 4500, weight: 0.25, stock: 40, icon: "fa-lightbulb", badge: null, desc: "WiFi/Bluetooth smart bulb. Change colours via app. Works with voice assistants." },
  { id: 36, name: "LED Panel Light 18W Square", category: "lighting", price: 3800, weight: 1.0, stock: 50, icon: "fa-square", badge: null, desc: "Slim LED panel for ceilings. Even light distribution, low heat." },

  // Home Appliances
  { id: 37, name: "TV Stand Glass & Wood 55\"", category: "appliances", price: 38500, weight: 32, stock: 10, icon: "fa-tv", badge: "Popular", desc: "Modern TV stand with glass shelves. Fits up to 55-inch TV. Sturdy and stylish." },
  { id: 38, name: "Gaming Console Stand with Cooling", category: "appliances", price: 12500, weight: 4.5, stock: 30, icon: "fa-gamepad", badge: null, desc: "Vertical stand for PS5/Xbox with cooling fans and controller holders." },
  { id: 39, name: "Blender 1.5L 500W", category: "appliances", price: 18500, weight: 6.0, stock: 20, icon: "fa-blender", badge: null, desc: "Powerful kitchen blender with multiple speeds. Stainless steel blades." },
  { id: 40, name: "Electric Kettle 1.8L Stainless", category: "appliances", price: 9800, weight: 2.2, stock: 35, icon: "fa-mug-hot", badge: null, desc: "Fast-boil electric kettle. Auto shut-off, cordless base, stainless steel." },
  { id: 41, name: "Microwave Oven 20L", category: "appliances", price: 52000, weight: 24, stock: 15, icon: "fa-microchip", badge: null, desc: "Compact microwave with multiple power levels and defrost function." },

  // Audio / Speakers
  { id: 42, name: "Bluetooth Speaker Portable 20W", category: "audio", price: 14500, weight: 1.5, stock: 40, icon: "fa-volume-up", badge: "Popular", desc: "Waterproof Bluetooth speaker. Deep bass, 12-hour battery, outdoor ready." },
  { id: 43, name: "MP3 Speaker with USB/SD/FM", category: "audio", price: 8500, weight: 2.0, stock: 30, icon: "fa-music", badge: null, desc: "Multi-function MP3 speaker. Plays from USB, SD card, FM radio and Bluetooth." },
  { id: 44, name: "Home Theatre 5.1 Speaker System", category: "audio", price: 68500, weight: 22, stock: 12, icon: "fa-speaker", badge: null, desc: "Complete 5.1 surround system with subwoofer. Ideal for movies and music." },
  { id: 45, name: "Wireless Earbuds TWS", category: "audio", price: 7500, weight: 0.3, stock: 50, icon: "fa-headphones", badge: "Sale", desc: "True wireless earbuds with charging case. Clear sound, touch controls." },

  // Chargers & Power Banks
  { id: 46, name: "Power Bank 20000mAh Fast Charge", category: "power", price: 12500, weight: 0.9, stock: 60, icon: "fa-battery-full", badge: "Best Seller", desc: "High-capacity power bank with dual USB ports and fast charging support." },
  { id: 47, name: "USB-C Fast Charger 65W", category: "power", price: 8500, weight: 0.35, stock: 45, icon: "fa-plug", badge: null, desc: "GaN fast charger. Compatible with phones, laptops and tablets." },
  { id: 48, name: "Wireless Charger Pad 15W", category: "power", price: 5500, weight: 0.4, stock: 55, icon: "fa-wifi", badge: null, desc: "Qi wireless charging pad. Fast charge compatible phones. LED indicator." },
  { id: 49, name: "Car Charger Dual USB 3.4A", category: "power", price: 2800, weight: 0.2, stock: 80, icon: "fa-car", badge: null, desc: "Dual-port car charger. Fast charging for two devices simultaneously." },
  { id: 50, name: "Power Bank 10000mAh Slim", category: "power", price: 7500, weight: 0.5, stock: 50, icon: "fa-battery-half", badge: null, desc: "Slim and lightweight power bank. Perfect for travel. Dual output." },

  // Peer-to-Peer
  { id: 51, name: "Used Standing Fan – Good Condition", category: "p2p", price: 12000, weight: 8.0, stock: 3, icon: "fa-fan", badge: "P2P", desc: "Clean used standing fan. Working perfectly. Seller in Port Harcourt. Inspection welcome." },
  { id: 52, name: "Second-hand Microwave 20L", category: "p2p", price: 28000, weight: 22, stock: 2, icon: "fa-microchip", badge: "P2P", desc: "Gently used microwave. Fully functional. Available for viewing at Rukpokwu area." },
  { id: 53, name: "Used Bluetooth Speaker", category: "p2p", price: 6000, weight: 1.2, stock: 5, icon: "fa-volume-up", badge: "P2P", desc: "Portable Bluetooth speaker in good condition. Battery holds charge well." },
  { id: 54, name: "Pre-owned TV Stand 43\"", category: "p2p", price: 18000, weight: 25, stock: 1, icon: "fa-tv", badge: "P2P", desc: "Wooden TV stand. Minor scratches, solid structure. Pickup only." },
  { id: 55, name: "Used Generator 2.5KVA", category: "p2p", price: 95000, weight: 55, stock: 2, icon: "fa-server", badge: "P2P", desc: "Well-maintained 2.5KVA generator. Low hours. Comes with fuel can and manual." }
];

/* Dynamic categories – admin can add more */
let CATEGORIES = JSON.parse(localStorage.getItem("mcCategories") || "null") || [
  { id: "electrical", name: "Electrical Parts" },
  { id: "mechanical", name: "Mechanical Parts" },
  { id: "car", name: "Car Parts" },
  { id: "generator", name: "Generator Parts" },
  { id: "tools", name: "Repair Tools" },
  { id: "warehouse", name: "Warehouse Parts" },
  { id: "fans", name: "Solar Fans" },
  { id: "lighting", name: "Bulbs & Lighting" },
  { id: "appliances", name: "Home Appliances" },
  { id: "audio", name: "Speakers & Audio" },
  { id: "power", name: "Chargers & Power Banks" },
  { id: "p2p", name: "Peer-to-Peer Sales" }
];

function getCategoryNames() {
  var map = { all: "All Products" };
  CATEGORIES.forEach(function (c) { map[c.id] = c.name; });
  return map;
}
var CATEGORY_NAMES = getCategoryNames();

/* Shipping rates (overridden by admin policy) */
const SHIPPING = {
  nigeriaPerLb: 107,
  internationalPerLb: 0.92,
  usdToNgn: 1600
};

/* Welcome gift card – every new customer gets one at random */
const GIFT_TYPES = [
  { type: "discount", label: "Discount", min: 5, max: 15, unit: "%" },
  { type: "cash", label: "Cash Bonus", min: 500, max: 5000, unit: "₦" },
  { type: "product", label: "Product Bonus", min: 1, max: 1, unit: "free item" }
];

function generateGiftCard(userId) {
  var pick = GIFT_TYPES[Math.floor(Math.random() * GIFT_TYPES.length)];
  var value;
  if (pick.type === "discount") {
    value = Math.floor(Math.random() * (pick.max - pick.min + 1)) + pick.min;
  } else if (pick.type === "cash") {
    value = (Math.floor(Math.random() * ((pick.max - pick.min) / 100 + 1)) * 100) + pick.min;
  } else {
    value = 1;
  }
  var code = "MCG-" + Math.random().toString(36).slice(2, 6).toUpperCase() + "-" + Date.now().toString(36).toUpperCase().slice(-4);
  return {
    code: code,
    type: pick.type,
    value: value,
    label: pick.label,
    userId: userId,
    used: false,
    createdAt: new Date().toISOString()
  };
}
